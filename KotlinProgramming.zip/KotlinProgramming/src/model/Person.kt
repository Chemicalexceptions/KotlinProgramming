package model

class Person(var name :String) {

    fun display(){

        println("${name}")

    }
}