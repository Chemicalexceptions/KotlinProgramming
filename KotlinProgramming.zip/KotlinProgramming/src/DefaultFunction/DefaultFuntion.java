package DefaultFunction;

public class DefaultFuntion {

    public static void main(String[] args) {


        System.out.println( DefaultKotlinFunction.findVolume(2,3));
    }
}
