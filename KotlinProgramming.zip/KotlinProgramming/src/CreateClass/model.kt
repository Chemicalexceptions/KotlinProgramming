package CreateClass

class model(var name: String, var number: String, var desig: String)

